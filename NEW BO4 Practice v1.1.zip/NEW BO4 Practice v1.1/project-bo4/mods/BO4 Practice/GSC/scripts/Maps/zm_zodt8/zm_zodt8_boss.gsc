zm_zodt8_boss_setup()
{
    self endon( "disconnect" );
    level flag::wait_till( "start_zombie_round_logic" );
    thread zombie_open_sesame();
    foreach ( player in GetPlayers() )
    {
        player thread zm_perks::function_cc24f525();
        player zm_weapons::weapon_give(GetWeapon( "launcher_standard_t8_upgraded" ));
        player zm_utility::function_28ee38f4(GetWeapon( "launcher_standard_t8_upgraded" ),0, 2);
        player zm_weapons::weapon_give(GetWeapon( "pistol_topbreak_t8_upgraded" ));
        player zm_utility::function_28ee38f4(GetWeapon( "pistol_topbreak_t8_upgraded" ),0,4);
        player zm_weapons::weapon_give(GetWeapon( "homunculus" ) );
        player zm_weapons::weapon_give(GetWeapon("zhield_dw"));
        player zm_weapons::weapon_give(GetWeapon( "ww_tricannon_earth_t8_upgraded" ) );
        player GadgetPowerSet( level.var_a53a05b5, 100 );
        player SetEverHadWeaponAll( 1 );
        
    }

    wait 5;
    thread zm_zodt8_boss_practice_start();
    IPrintLnBold( "Voyage Boss Patch" );
}









zm_zodt8_boss_practice_start()
{
    
    zm_sq::start( #"boss_fight" );
    level [[ @zodt8_eye<scripts\zm\zm_zodt8_eye.gsc>::boss_teleport_players]]( "pd" );
}