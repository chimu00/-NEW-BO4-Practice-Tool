zm_zodt8_planets_setup()
{
    self endon( "disconnect" );
    level flag::wait_till( "start_zombie_round_logic" );
    thread zombie_open_sesame();
    goto_round( 13 );
    foreach ( player in GetPlayers() )
    {
        player thread zm_perks::function_cc24f525();
        player.score = 111110;
        player SetOrigin( ( -15.9896, -94.7161, 167.87 ) );
        player zm_weapons::weapon_give(GetWeapon( "launcher_standard_t8_upgraded" ));
        player zm_utility::function_28ee38f4(GetWeapon( "launcher_standard_t8_upgraded" ),0, 2);
        player zm_weapons::weapon_give(GetWeapon( "pistol_topbreak_t8_upgraded" ));
        player zm_utility::function_28ee38f4(GetWeapon( "pistol_topbreak_t8_upgraded" ),0,2);
        player zm_weapons::weapon_give(GetWeapon( "ww_tricannon_earth_t8_upgraded" ) );
        player zm_weapons::weapon_give(GetWeapon( "homunculus" ) );
        player zm_weapons::weapon_give(GetWeapon("zhield_dw"));
        player GadgetPowerSet( level.var_a53a05b5, 100 );
        player SetEverHadWeaponAll( 1 );
    }

    wait 2;

        level flag::wait_till( #"water_initialized" );
        level thread [[@zm_zodt8<scripts\zm\zm_zodt8.gsc>::change_water_height_fore]](1);
    wait 5;

        level.s_pap_quest.var_4ee2e2ab = 0;
        level.s_pap_quest.var_be6e6f65 =
        level.s_pap_quest.var_ac28fc4d;
        level flag::set( "pap_quest_complete" );
        level flag::set( #"hash_76dd603f61fa542d" );

    wait 1;

        level thread [[@zodt8_sentinel<scripts\zm\zm_zodt8_sentinel_trial.gsc>::function_443b1ad2]](0);

    wait 1;

        level [[@zodt8_sentinel<scripts\zm\zm_zodt8_sentinel_trial.gsc>::function_9d73036a]]();

    wait 1;

    IPrintLnBold( "Planets Patch" );
}




