detour zm_red_main_quest<scripts\zm\zm_red_main_quest.gsc>::function_3c71e07d()
{
    self notify( "a7b89283a4c0771" );
    self endon( "a7b89283a4c0771" );

    level endon( #"end_game", #"sundial_puzzle" + "_ended_early", #"end_of_round", #"hash_1995757cb678aacb" );

    s_prophecy = level.var_cc9c60d2;
    mdl_spear = s_prophecy.mdl_spear;
    v_spear = mdl_spear.origin;

    for ( i = 0; i < 3; i++ )
    {
        b_has_spawned = 0;

        while ( true )
        {
            wait 1;

            if ( isdefined( s_prophecy.var_d7ebba27 ) && s_prophecy.var_d7ebba27 )
            {
                continue;
            }

            a_ai_catalysts = getaiarchetypearray( #"catalyst" );
            b_can_spawn = 1;

            foreach ( ai_catalyst in a_ai_catalysts )
            {
                if ( isalive( ai_catalyst ) && ai_catalyst.subarchetype == #"catalyst_electric" )
                {
                    b_can_spawn = 0;
                    break;
                }
            }

            if ( b_can_spawn && !zm_transform::function_abf1dcb4( #"catalyst_electric" ) )
            {
                a_ai_zombies = getaiarchetypearray( #"zombie" );
                a_ai_zombies = array::randomize( a_ai_zombies );

                foreach ( ai_zombie in a_ai_zombies )
                {
                    if ( isdefined( ai_zombie.completed_emerging_into_playable_area )
                        && ai_zombie.completed_emerging_into_playable_area
                        && !zm_utility::is_magic_bullet_shield_enabled( ai_zombie )
                        && !( isdefined( ai_zombie.marked_for_death ) && ai_zombie.marked_for_death )
                        && !( isdefined( ai_zombie.var_94c53b42 ) && ai_zombie.var_94c53b42 )
                        && !( isdefined( ai_zombie.var_52531256 ) && ai_zombie.var_52531256 )
                        && !( isdefined( ai_zombie.var_3c394b1b ) && ai_zombie.var_3c394b1b )
                        && ai_zombie zm_ai_utility::function_db610082() )
                    {
                        b_has_spawned = 1;
                        level thread zm_transform::function_9acf76e6( ai_zombie, #"catalyst_electric" );
                        break;
                    }
                }
            }

            if ( b_has_spawned )
            {
                break;
            }
        }
    }
}