detour zm_red_boss_battle<scripts\zm\zm_red_boss_battle.gsc>::function_d9802986()
{
    if ( level.s_boss_battle.n_stage == 3 )
    {
        level thread [[ @zm_red_boss_battle<scripts\zm\zm_red_boss_battle.gsc>::function_4a58a0 ]]( level.s_boss_battle.mdl_perseus );
        return;
    }

    // leave this empty only if you want to block flame outside stage 3 too
}