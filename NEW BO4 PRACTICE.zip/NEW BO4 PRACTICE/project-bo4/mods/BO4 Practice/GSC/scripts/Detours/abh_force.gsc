is_zm_red_map()
{
    if ( isdefined(level.script) && level.script == "zm_red" )
        return 1;

    if ( isdefined(level.scriptname) && level.scriptname == "zm_red" )
        return 1;

    return 0;
}

detour zm_bgb_anywhere_but_here<scripts\zm_common\bgbs\zm_bgb_anywhere_but_here.gsc>::function_91a62549()
{
    if ( !is_zm_red_map() )
    {
        return [[ @zm_bgb_anywhere_but_here<scripts\zm_common\bgbs\zm_bgb_anywhere_but_here.gsc>::function_91a62549 ]]();
    }

    if ( !isdefined(level._abh_force_index) )
        level._abh_force_index = 0;

    if ( level._abh_force_index == 0 )
        forced = (439, -4107, -677);
    else
        forced = (-1651.48, 8943.83, 318.722);

    nav = getclosestpointonnavmesh(forced, 256, 24);
    if ( isdefined(nav) )
        forced = nav;

    s_forced = struct::spawn(forced, self.angles);
    s_forced.origin = forced;
    s_forced.angles = self.angles;

    return s_forced;
}

detour zm_bgb_anywhere_but_here<scripts\zm_common\bgbs\zm_bgb_anywhere_but_here.gsc>::activation()
{
    if ( !is_zm_red_map() )
    {
        return [[ @zm_bgb_anywhere_but_here<scripts\zm_common\bgbs\zm_bgb_anywhere_but_here.gsc>::activation ]]();
    }

    ret = [[ @zm_bgb_anywhere_but_here<scripts\zm_common\bgbs\zm_bgb_anywhere_but_here.gsc>::activation ]]();

    if ( !isdefined(level._abh_force_index) )
        level._abh_force_index = 0;

    level._abh_force_index = (level._abh_force_index + 1) % 2;

    return ret;
}