detour zm_red_ww_quests<scripts\zm\zm_red_ww_quests.gsc>::function_9c17f532()
{
    
    forced_ids = array( 4, 15, 17, 7 );

    
    a_e_hands = getentarray( "s_ww_quests_dormant_hand", "script_noteworthy" );

   
    if ( !isdefined(a_e_hands) || !isarray(a_e_hands) || a_e_hands.size == 0 )
    {
        return [[ @zm_red_ww_quests<scripts\zm\zm_red_ww_quests.gsc>::function_9c17f532 ]]();
    }

    
    foreach ( e_hand in a_e_hands )
    {
        e_hand hide();
    }

    
    a_hands = arraycombine(
        a_e_hands,
        struct::get_array( #"s_ww_quests_dormant_hand", "script_noteworthy" ),
        0, 0
    );

    forced = [];

    
    foreach ( id in forced_ids )
    {
        found = undefined;

        foreach ( h in a_hands )
        {
            if ( isdefined(h.script_int) && h.script_int == id )
            {
                found = h;
                break;
            }
        }

        
        if ( !isdefined(found) )
        {
            return [[ @zm_red_ww_quests<scripts\zm\zm_red_ww_quests.gsc>::function_9c17f532 ]]();
        }

        forced[ forced.size ] = found;
    }

   
    level thread [[
        @zm_red_ww_quests<scripts\zm\zm_red_ww_quests.gsc>::function_65bda766
    ]]( forced );

    
    return;
}
detour zm_red_ww_quests<scripts\zm\zm_red_ww_quests.gsc>::function_e695bb99()
{
    var_e2604798 = struct::get_array( "s_ww_death_coin", "targetname" );

    if ( !isdefined( var_e2604798 ) || !isarray( var_e2604798 ) || var_e2604798.size == 0 )
    {
        return [[ @zm_red_ww_quests<scripts\zm\zm_red_ww_quests.gsc>::function_e695bb99 ]]();
    }

    v0 = ( -1035, 6732, 943 );
    v1 = ( -326, 7552, 663 );
    v2 = ( -645, 7642, 710 );

    s0 = undefined;
    s1 = undefined;
    s2 = undefined;

    foreach ( s in var_e2604798 )
    {
        if ( !isdefined( s ) )
            continue;

        if ( !isdefined( s0 ) && s.origin == v0 ) { s0 = s; continue; }
        if ( !isdefined( s1 ) && s.origin == v1 ) { s1 = s; continue; }
        if ( !isdefined( s2 ) && s.origin == v2 ) { s2 = s; continue; }
    }

    if ( !isdefined( s0 ) || !isdefined( s1 ) || !isdefined( s2 ) )
    {
        return [[ @zm_red_ww_quests<scripts\zm\zm_red_ww_quests.gsc>::function_e695bb99 ]]();
    }

    forced_list = [];
    forced_list[ forced_list.size ] = s0;
    forced_list[ forced_list.size ] = s1;
    forced_list[ forced_list.size ] = s2;

    foreach ( s in var_e2604798 )
    {
        if ( !isdefined( s ) )
            continue;

        if ( s == s0 || s == s1 || s == s2 )
            continue;

        forced_list[ forced_list.size ] = s;
    }

    var_e2604798 = forced_list;

    // ---- original body , but with qualified helper calls ----
    self.var_167b59c7 = getentarray( "mdl_ww_death_real_coin", "targetname" );

    foreach ( mdl_coin in self.var_167b59c7 )
    {
        mdl_coin hidepart( "tag_emissive" );
    }

    self.var_18fd25ab = [];

    for ( i = 0; i < self.var_167b59c7.size ; i++ )
    {
        self.var_167b59c7[ i ].origin = var_e2604798[ 0 ].origin;
        self.var_167b59c7[ i ].angles = var_e2604798[ 0 ].angles;
        self.var_18fd25ab[ i ] = var_e2604798[ 0 ];
        var_e2604798 = array::remove_index( var_e2604798, 0 );

        self thread [[
            @zm_red_ww_quests<scripts\zm\zm_red_ww_quests.gsc>::function_ab234072
        ]]( i );
    }

    var_2dd44c8 = getentarray( "mdl_ww_death_false_coin", "targetname" );

    foreach ( mdl_coin in var_2dd44c8 )
    {
        mdl_coin hidepart( "tag_emissive" );
    }

    for ( i = 0; i < var_e2604798.size ; i++ )
    {
        if ( isdefined( var_e2604798[ i ] ) && isdefined( var_2dd44c8[ i ] ) )
        {
            var_2dd44c8[ i ].origin = var_e2604798[ i ].origin;
            var_2dd44c8[ i ].angles = var_e2604798[ i ].angles;

            var_2dd44c8[ i ] thread [[
                @zm_red_ww_quests<scripts\zm\zm_red_ww_quests.gsc>::function_8f228be7
            ]]();
        }
    }

    return;
}
