detour zm_red_challenges_rewards<scripts\zm\zm_red_challenges_rewards.gsc>::function_56c888ce( a_str_rewards )
{
    if ( isdefined(a_str_rewards) && isarray(a_str_rewards) )
    {
        foreach ( i, r in a_str_rewards )
        {
            if ( r == #"weapon" )
            {
                return #"weapon";
            }
        }
    }

    return [[ @zm_red_challenges_rewards<scripts\zm\zm_red_challenges_rewards.gsc>::function_56c888ce ]]( a_str_rewards );
}

detour zm_red_challenges_rewards<scripts\zm\zm_red_challenges_rewards.gsc>::function_123bcbcf()
{
    
    [[ @zm_red_challenges_rewards<scripts\zm\zm_red_challenges_rewards.gsc>::function_123bcbcf ]]();

    
    if ( isdefined(self) && isdefined(self.s_tribute_bowl) && isdefined(self.s_tribute_bowl.var_8f683ef8) )
    {
        self thread [[ @zm_red_challenges_rewards<scripts\zm\zm_red_challenges_rewards.gsc>::function_e08e4c9c ]]( #"zm_bgb_shields_up", self.s_tribute_bowl.var_8f683ef8 );
    }

    return;
}