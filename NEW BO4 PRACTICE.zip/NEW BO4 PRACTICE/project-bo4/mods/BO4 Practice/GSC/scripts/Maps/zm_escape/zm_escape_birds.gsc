zm_escape_birds_setup() {
    iPrintLnBold("Bird practice");
    self.score = 7500;
    self thread zm_perks::function_cc24f525();
   foreach (weapon in self GetWeaponsListPrimaries()) {
        self TakeWeapon(weapon);
    }
    self zm_weapons::weapon_give(GetWeapon("smg_fastfire_t8"), 0, 1, 334);
    self zm_weapons::weapon_give(GetWeapon("ar_stealth_t8"), 0, 1, 334);
    // Give tony
    self zm_weapons::weapon_give(GetWeapon("tomahawk_t8"));
    
    // Give <something>
    self GiveWeapon(level.var_d7e67022);

    // Give Spoon
    self GiveWeapon(GetWeapon("spoon_alcatraz"));

    wait 0.1;

    // Idk
    self.var_9fd623ed = 6;
    self.var_9fd623ed = self.var_9fd623ed + 12;
    self.var_9fd623ed = math::clamp(self.var_9fd623ed, 0, self.var_f7c822b5 * 3);

    // Shield
    self thread [[ @zm_weap_spectral_shield<scripts\zm\weapons\zm_weap_spectral_shield.gsc>::function_804309c ]]();
    self notify(#"hash_22a49f7903e394a5");
    self playsound(#"hash_19d5ba8ff22edcce");
    self.var_184a3854 = 2750;
    self.var_184a3854 = 3050;
    self SetEverHadWeaponAll(1);

    // Set location: Want to start in spawn to interact with book
    if (level.patch_settings.patch != "boss") {
        // self SetOrigin((-1850, 7880, 1430));
        // self SetPlayerAngles((0, 90, 0));
        self FreezeControls(1);
        self val::set(#"hash_69d303dd5e34b7b7", "ignoreme");
    }

    if (!self IsHost()) {
        return;
    }

    // Build shield
    self craft_parts();

    // Open all doors
    SetSlowMotion(1, 10, 0.05);
    thread zombie_open_sesame();

    // Do catwalk event and remove zombies
    level flag::wait_till_any(array("power_on2", "power_on"));
    wait 0.1;
    getent("t_catwalk_door_open", "targetname") notify("trigger", {#activator:self});
    wait 0.1;
    trigger::use("t_catwalk_event_00", "targetname", self);
    level flag::wait_till(#"hash_6019aeb57ae7e6b5");
    wait 0.5;
    getent("t_catwalk_event_10", "targetname") notify("enemies_spawned");
    level.var_20cff6f0 = 0;
    foreach (ai_zombie in GetEntArray("catwalk_event_zombie", "script_noteworthy")) {
        ai_zombie Kill();
    }
    wait 0.1;
    level.var_e120ae98 = undefined;
    level flag::set("catwalk_event_completed");
    level notify("7208d0e939378c16");
    level notify("trig_catwalk_event_completed");
    foreach (t_catwalk_event in GetEntArray("catwalk_event_triggers", "script_noteworthy")) {
        t_catwalk_event Delete();
    }

    round = 1;
    while (level.var_33be9958 <= 12) {
        level.var_33be9958 = round + RandomIntRange(level.var_deee7afe, level.var_66ff42da);
        round = level.var_33be9958;
    }

    // Drops logic
    level flag::clear("zombie_drop_powerups");
    while (level.n_total_kills < 200) {
        n_kills_needed = zm_powerups::function_2ff352cc();
        level.n_total_kills = level.n_total_kills + n_kills_needed;
        level [[ @zm_powerups<scripts\zm_common\zm_powerups.gsc>::function_a7a5570e ]]();
    }
    level.var_1dce56cc = level.n_total_kills + zm_powerups::function_2ff352cc();
    level flag::set("zombie_drop_powerups");

    // Fill all dogs
    foreach (dog in level.var_4952e1) {
        dog notify(#"hash_13c5316203561c4f");
        level.n_soul_catchers_charged++;
        dog.is_charged = 1;
        dog notify("fully_charged");
        level thread [[ @zm_escape_weap_quest<scripts\zm\zm_escape_weap_quest.gsc>::function_5fd2c72e ]]();
        dog.var_740e1e0e clientfield::set("" + #"hash_5ecbfb9042fc7f38", 0);
        dog.var_740e1e0e SetModel("p8_zm_esc_dream_catcher");
    }
    level flag::set("soul_catchers_charged");

    // Idk
    level flag::set(#"hash_7039457b1cc827de");
    wait 0.1;
    getent("nixie_door_trigger", "targetname") notify("trigger");

    wait 5;
    // Set round 9
    goto_round(9);

    wait 40;

    // Set ABH as used
    old_bgb_func = level.bgb["zm_bgb_anywhere_but_here"].activation_func;
    level.bgb["zm_bgb_anywhere_but_here"].activation_func = &empty_func;
    level.bgb["zm_bgb_anywhere_but_here"].var_81f8ab0f = 240;

    SetSlowMotion(10, 1, 0.05);
    zm_vo::function_3c173d37(self.origin, 10000);
    foreach (player in level.activeplayers) {
        player util::delay(5, undefined, &val::reset, #"hash_69d303dd5e34b7b7", "ignoreme");
        player FreezeControls(0);
        foreach (n_index, bgb in player.bgb_pack) {
            if (bgb == #"zm_bgb_anywhere_but_here") {
                player bgb_pack::activate_elixir(n_index);
                break;
            }
        }
    }

    level.var_973488a5 = 11 + RandomIntRangeInclusive(6, 8);
    level thread zombie_dog_util::dog_enable_rounds(1);
    level.dog_round_count = 3;
    zombie_utility::set_zombie_var("zombie_drop_item", 0);

    self waittill("end_slot_cooldown" + n_index);
    foreach (player in GetPlayers()) {
        player [[ @bgb_pack<scripts\zm_common\zm_bgb_pack.gsc>::function_f2173c97 ]](0);
    }
    level.bgb["zm_bgb_anywhere_but_here"].activation_func = old_bgb_func;
    level.bgb["zm_bgb_anywhere_but_here"].var_81f8ab0f = undefined;

    

    // THIS HASH IS FOR THE BOOK INTERACT IN SPAWN TO START STEP 2
    level waittill(#"hash_6da514c90059d5c2");

    

    // Reset timer when hitting book
    level clientfield::set_world_uimodel("ZMHudGlobal.trials.gameStartTime", GetTime());

    // self thread print_coords();
    self thread print_zone();
    self thread print_birds();
    
}


print_birds() {
    self endon("disconnect");
    while (true) {
        // Break out after round 10
        if (level.round_number > 13) {
            return;
        }

        if (level.round_number == 9) {
            level waittill(#"between_round_over");
            continue;
        }

        wait 3; 

        s_seagull = struct::get("s_p_s2_gul");

        if (isDefined(s_seagull)) {
            IPrintLnBold("Bird movin");
            IPrintLnBold(level.var_dcc985c4.script_string);
        }

        level waittill(#"between_round_over");
    }
}

print_coords() {
    self endon("disconnect");
    player = level.players[0];

    while (true) {
        iPrintLn("Player: " + player.origin[0] + ", " + player.origin[1] + ", " + player.origin[2]);
        wait 10;
    }
    
}

print_zone() {
    self endon("disconnect");
    while (true) {
        str_zone = self zm_utility::get_current_zone();
        IPrintLn(str_zone);
        wait 10;
    }
    
}

print_vec(v) {
    if (!isDefined(v)) {
        return "undefined vector";
    }

    return "(" + v[0] + ", " + v[1] + ", " + v[2] + ")";
}