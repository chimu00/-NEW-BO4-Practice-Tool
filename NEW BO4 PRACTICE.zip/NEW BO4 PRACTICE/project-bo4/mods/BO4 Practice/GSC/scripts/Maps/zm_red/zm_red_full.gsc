zm_red_full_setup()
{
   self endon("disconnect");

level flag::wait_till("fl_challenges_initialized");
wait 5;

if ( isdefined(level.zm_red_full_done) && level.zm_red_full_done )
    return;
level.zm_red_full_done = 1;

if ( !isdefined(level.a_s_challenges) )
    return;

specialistIndex = -1;
noDamageIndex   = -1;

// Find both challenge indexes
foreach ( index, s_challenge in level.a_s_challenges )
{
    if ( isdefined(s_challenge.n_id) )
    {
        if ( s_challenge.n_id == 12 )
            specialistIndex = index;

        else if ( s_challenge.n_id == 10 )
            noDamageIndex = index;
    }
}

// Must find both
if ( specialistIndex == -1 || noDamageIndex == -1 )
    return;

// --- Move Specialist to slot 0 ---
if ( specialistIndex != 0 )
{
    temp = level.a_s_challenges[0];
    level.a_s_challenges[0] = level.a_s_challenges[specialistIndex];
    level.a_s_challenges[specialistIndex] = temp;

    // If noDamage was originally in slot 0, its index changed
    if ( noDamageIndex == 0 )
        noDamageIndex = specialistIndex;
}

// --- Move Do Not Take Damage to slot 1 ---
if ( noDamageIndex != 1 )
{
    temp = level.a_s_challenges[1];
    level.a_s_challenges[1] = level.a_s_challenges[noDamageIndex];
    level.a_s_challenges[noDamageIndex] = temp;
}
  
level flag::wait_till("zombie_drop_powerups");

oldSize = 0;
while ( oldSize == 0 || level.zombie_powerup_array.size != oldSize )
{
    oldSize = level.zombie_powerup_array.size;
    wait(1);
}

// find indexes
nukeIndex = -1;
hpIndex   = -1;

for ( i = 0; i < level.zombie_powerup_array.size; i++ )
{
    if ( level.zombie_powerup_array[i] == "nuke" )
        nukeIndex = i;
    else if ( level.zombie_powerup_array[i] == "hero_weapon_power" )
        hpIndex = i;
}

// if either isn't found, do nothing (prevents bad swaps)
if ( nukeIndex == -1 || hpIndex == -1 )
{
    return;
}

// move nuke to slot 0
if ( nukeIndex != 0 )
{
    temp = level.zombie_powerup_array[0];
    level.zombie_powerup_array[0] = level.zombie_powerup_array[nukeIndex];
    level.zombie_powerup_array[nukeIndex] = temp;

    // if hero_weapon_power was at 0, its index moved to nukeIndex
    if ( hpIndex == 0 )
        hpIndex = nukeIndex;
}

// move hero_weapon_power to slot 1
if ( hpIndex != 1 )
{
    temp = level.zombie_powerup_array[1];
    level.zombie_powerup_array[1] = level.zombie_powerup_array[hpIndex];
    level.zombie_powerup_array[hpIndex] = temp;
}

wait(1);

    
        

iprintlnbold("FULL");

}

