zm_mansion_full_setup()
{
 self endon(#"disconnect", #"spawned_player");
    level endon(#"end_game", #"game_ended");
    level flag::wait_till("zombie_drop_powerups");

oldSize = 0;
while ( oldSize == 0 || level.zombie_powerup_array.size != oldSize )
{
    oldSize = level.zombie_powerup_array.size;
    wait(1);
}

// find indexes
dpIndex = -1;
bpIndex   = -1;

for ( i = 0; i < level.zombie_powerup_array.size; i++ )
{
    if ( level.zombie_powerup_array[i] == "double_points" )
        dpIndex = i;
    else if ( level.zombie_powerup_array[i] == "bonus_points_team" )
        bpIndex = i;
}


if ( dpIndex == -1 || bpIndex == -1 )
{
    return;
}


if ( dpIndex != 0 )
{
    temp = level.zombie_powerup_array[0];
    level.zombie_powerup_array[0] = level.zombie_powerup_array[dpIndex];
    level.zombie_powerup_array[dpIndex] = temp;

 
    if ( bpIndex == 0 )
        bpIndex = dpIndex;
}


if ( bpIndex != 1 )
{
    temp = level.zombie_powerup_array[1];
    level.zombie_powerup_array[1] = level.zombie_powerup_array[bpIndex];
    level.zombie_powerup_array[bpIndex] = temp;
}

iprintlnbold("FULL");
}




