zm_red_cogs_setup()
{
  self endon("disconnect");
	thread zombie_open_sesame();
foreach (player in GetPlayers()) {
        player.score = 111110;
       
player zm_weapons::weapon_give(GetWeapon("zhield_zpear_dw"));
player zm_weapons::weapon_give(GetWeapon("ww_hand_c"));
        player GadgetPowerSet(level.var_a53a05b5, 100);
        player SetEverHadWeaponAll(1);
        player SetOrigin((439, -4107, -677));
		foreach (n_slot, str_perk in player.var_c27f1e90) {
            if (str_perk == "specialty_staminup") {
                player thread zm_perks::function_9bdf581f(str_perk, n_slot);
                break;
            }
        }
  wait 1;
       
        goto_round(9);

wait 10;

}

    
    

    level flag::set("fl_oracle_unlocked");
    level flag::set(#"pegasus_exited");
    level flag::set(#"pap_quest_completed");
    level flag::set( #"zm_red_fasttravel_open" );
    level flag::set(#"oil_completed");

    wait(15);
iprintlnbold("Charge shot to start Statues");
level clientfield::set_world_uimodel("ZMHudGlobal.trials.gameStartTime", GetTime());
}