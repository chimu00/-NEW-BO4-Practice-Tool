zm_red_debug_setup()
{
  self endon("disconnect");
	thread zombie_open_sesame();
    thread print_coords_loop();
foreach (player in GetPlayers()) {
        player.score = 111110;
       
player zm_weapons::weapon_give(GetWeapon("zhield_zpear_dw"));
player zm_weapons::weapon_give(GetWeapon("ww_hand_g"));
        player GadgetPowerSet(level.var_a53a05b5, 100);
        player SetEverHadWeaponAll(1);
        
		foreach (n_slot, str_perk in player.var_c27f1e90) {
            if (str_perk == "specialty_staminup") {
                player thread zm_perks::function_9bdf581f(str_perk, n_slot);
                break;
            }
        }
  
       
	goto_round(2);
       



}
level flag::set("fl_oracle_unlocked");
    level flag::set(#"pegasus_exited");

    wait(2);

    level flag::set(#"pap_quest_completed");
    level flag::set(#"oil_completed");

    wait(2);

    level flag::set(#"hash_4e74b4172497a14a");
    level notify(#"hash_103477b55ed9a149");
    level flag::set(#"monument_changed");
    level flag::set(#"monument_shot");
    level flag::set( #"split_completed" );
     wait(2);

    
    
    
    
   


        
        
       

    wait (2);
}
print_coords_loop()
{
    self endon("disconnect");
    self endon("death");

    while ( true )
    {
        origin = self.origin;

        iprintlnbold(
            "X: " + origin[0] + 
            "  Y: " + origin[1] + 
            "  Z: " + origin[2]
        );

        wait(10);
    }
}

test_velocity()
{
    self endon("disconnect");

while (1)
    {
        speed = int(length(self getvelocity()));

        iprintlnbold("Speed: " + speed);

        wait(0.25);
    }
}
