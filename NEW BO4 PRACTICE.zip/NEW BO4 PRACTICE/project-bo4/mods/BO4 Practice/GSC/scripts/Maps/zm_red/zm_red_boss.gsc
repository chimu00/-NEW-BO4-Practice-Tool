zm_red_boss_setup() {
    IPrintLnBold("AE Boss Rush");
thread zombie_open_sesame();
 foreach (player in GetPlayers()) {
        foreach (weapon in player GetWeaponsListPrimaries()) {
            player TakeWeapon(weapon);
        }
       player.score = 111110;
       player zm_weapons::weapon_give(GetWeapon("ww_hand_o"));
       player zm_weapons::weapon_give(GetWeapon("zhield_zpear_dw"));
        self SetEverHadWeaponAll(1);
      player GadgetPowerSet(level.var_a53a05b5, 100);
        foreach (n_slot, str_perk in player.var_c27f1e90) {
            if (str_perk == "specialty_staminup") {
                player thread zm_perks::function_9bdf581f(str_perk, n_slot);
            }

            else if (str_perk == "specialty_berserker") {
                player thread zm_perks::function_cc24f525();
                break;
            }
        
         else if (str_perk == "specialty_cooldown") {
                player thread zm_perks::function_cc24f525();
                break;
            }
        
        
        
        
        }
    }
  
   
    
    goto_round(11);
    wait 1;
    level thread [[
    @zm_red<scripts\zm\zm_red.gsc>::function_71a6c3ea
]]();

level thread [[
    @red_boss_battle<scripts\zm\zm_red_boss_battle.gsc>::function_3a2efd4e
]]( 1, 1, 1 );
wait 1;
self teleport_to_boss_fight(0);
   

}
teleport_to_boss_fight( b_all_players = 0 )
{
    a_tp = struct::get_array( "s_boss_arena_teleport" );
    
    if ( b_all_players )
    {
        a_players = getplayers();
        if ( !isdefined(a_players) || !isarray(a_players) || a_players.size == 0 )
            return;

        for ( i = 0; i < a_players.size; i++ )
        {
            if ( isdefined(a_players[i]) && i < a_tp.size )
            {
                a_players[i] setorigin( a_tp[i].origin );
                a_players[i] setplayerangles( a_tp[i].angles );
            }
        }

        
        return;
    }

    // self only
    self setorigin( a_tp[0].origin );
    self setplayerangles( a_tp[0].angles );
    level clientfield::set_world_uimodel("ZMHudGlobal.trials.gameStartTime", GetTime());
   
}