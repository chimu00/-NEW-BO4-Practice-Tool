zm_white_quest_init()
{
    switch (level.patch_settings.patch) {
     
        default: {
            break;
        }
    }
}

zm_white_practice()
{
    switch (level.patch_settings.patch) {
        case "boss": {
            thread zm_white_boss_setup();
            break;
        }
       
        default: {
            break;
        }
    }
  
}