zm_red_quest_init()
{
    switch (level.patch_settings.patch) {
     
        default: {
            break;
        }
    }
}

zm_red_practice()
{
    switch (level.patch_settings.patch) {
        case "cogs": {
            thread zm_red_cogs_setup();
            break;
        }
        case "full": {
            thread zm_red_full_setup();
            break;
        }
       case "debug": {
            thread zm_red_debug_setup();
            break;
        }
        case "boss": {
            thread zm_red_boss_setup();
            break;
        }
        default: {
            break;
        }
    }
  
}