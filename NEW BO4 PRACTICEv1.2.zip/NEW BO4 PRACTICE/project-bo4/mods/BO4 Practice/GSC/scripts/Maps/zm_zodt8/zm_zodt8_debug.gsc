zm_zodt8_debug_setup()
{


 self endon( "disconnect" );
    level flag::wait_till( "start_zombie_round_logic" );
    thread zombie_open_sesame();
    goto_round( 13 );
    foreach ( player in GetPlayers() )
    {
        player.score = 111110;
        
        player zm_weapons::weapon_give(
            GetWeapon( "ww_tricannon_t8_upgraded" ) );
        player zm_weapons::weapon_give(GetWeapon( "launcher_standard_t8_upgraded" ));

        player zm_utility::function_28ee38f4(GetWeapon( "launcher_standard_t8_upgraded" ),0, 2);

        player zm_weapons::weapon_give(GetWeapon( "pistol_topbreak_t8_upgraded" ));

        player zm_utility::function_28ee38f4(GetWeapon( "pistol_topbreak_t8_upgraded" ),0,4);
        player zm_weapons::weapon_give(
            GetWeapon( "homunculus" ) );
            player zm_weapons::weapon_give(GetWeapon("zhield_dw"));
        player GadgetPowerSet( level.var_a53a05b5, 100 );
        player SetEverHadWeaponAll( 1 );
        player thread zm_perks::function_cc24f525();
    }

       



}















