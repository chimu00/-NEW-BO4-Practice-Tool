zm_zodt8_practice()
{
    switch (level.patch_settings.patch) {
        case "free_kraken": {
            self thread zm_zodt8_free_kraken_helper();
            break;
        }
         case "planets": {
            thread zm_zodt8_planets_setup();
            break;
        }
          case "boss": {
            thread zm_zodt8_boss_setup();
            break;
        }
         case "debug": {
            thread zm_zodt8_debug_setup();
            break;
        }
        default: {
            return;
        }
    }
}